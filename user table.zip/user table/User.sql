create table  if not exists users (

id int,
name VARCHAR(100),
email VARCHAR(50),
password VARCHAR,
image VARCHAR,
role_id int

);


create table  if not exists role_id (
id int,
name VARCHAR(100),
);

    


