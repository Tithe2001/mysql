<?php


define("server","localhost");
define("user","root");
define("pass","");
define("database","batch66");

$db=new Mysqli(server,user,pass,database);

?>